from flask import Blueprint, request, jsonify
from models import Service, db

services_bp = Blueprint('services', __name__)

@services_bp.route('/list', methods=['GET'])
def list_services():
    services = Service.query.all()
    service_list = [{"id": s.id, "name": s.name, "description": s.description, "price": s.price} for s in services]
    return jsonify(service_list), 200

@services_bp.route('/add', methods=['POST'])
def add_service():
    data = request.json
    new_service = Service(name=data['name'], description=data['description'], price=data['price'], provider_id=data['provider_id'])
    db.session.add(new_service)
    db.session.commit()
    return jsonify({"message": "Service added successfully!"}), 201
