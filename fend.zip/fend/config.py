class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///zetaone.db'  # Update with your database URI
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = '99NNAA'
