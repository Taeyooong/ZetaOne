from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash

# Initialize extensions
db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    db.init_app(app)
    migrate.init_app(app, db)

    # Import models
    from models import User

    # Register Blueprints
    from routes.users import users_bp
    from routes.services import services_bp
    app.register_blueprint(users_bp, url_prefix='/users')
    app.register_blueprint(services_bp, url_prefix='/services')

    # Route for the homepage
    @app.route('/')
    def index():
        return render_template('index.html')

    # Route for the services page
    @app.route('/services')
    def services():
        return render_template('services.html')

    # Route for the book a service page
    @app.route('/book-service')
    def book_service():
        return render_template('book_service.html')

    # Route for the "How it Works" page
    @app.route('/how-it-works')
    def how_it_works():
        return render_template('how_it_works.html')

    # Route for the Support page
    @app.route('/support')
    def support():
        return render_template('support.html')

    # Route for the Login page
    @app.route('/login')
    def login():
        return render_template('login.html')

    # Route for the Register page (GET + POST)
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
        # Use application context
            with app.app_context():
            # Get form data
                name = request.form['name']
                email = request.form['email']
                password = request.form['password']

            # Check if the email already exists
                existing_user = User.query.filter_by(email=email).first()
                if existing_user:
                    flash('Email is already registered. Please login.', 'error')
                    return redirect(url_for('login'))

            # Hash the password
                hashed_password = generate_password_hash(password, method='sha256')

            # Create new user
                new_user = User(name=name, email=email, password=hashed_password)
                db.session.add(new_user)
                db.session.commit()

                flash('Registration successful! You can now log in.', 'success')
                return redirect(url_for('login'))

        return render_template('register.html')


    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
